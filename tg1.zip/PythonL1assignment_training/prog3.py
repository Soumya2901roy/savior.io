# Given a list of strings, 
# return a list with the strings in sorted order,
# except group all the strings that begin with 'x' first.  e.g. ['mix', 'xyz', 'apple', 'xanadu', 'aardvark'] yields 
# ['xanadu', 'xyz', 'aardvark', 'apple', 'mix'].  
# Hint: this can be done by making 2 lists and sorting each of them before combining them. 
# ['bbb', 'ccc', 'axx', 'xzz', 'xaa'] 
# ['mix', 'xyz', 'apple', 'xanadu', 'aardvark'] 
def sorting(str_list):
    final = []
    for item in str_list:
        if item[0] == 'x' or item[0] == 'X':
            final.append(item)          #creating the first list with the strings starting with 'x'
    for item in final:
        str_list.remove(item)           #creating the list of strings excluding the ones starting with 'x'
    return sorted(final) + sorted(str_list)

list1 = ['bbb', 'ccc', 'axx', 'xzz', 'xaa']
list2 = ['mix', 'xyz', 'apple', 'xanadu', 'aardvark']
print("Based on the given SORTING conditions: ")
print(f"Sorted list1 = {sorting(list1)}")
print(f"Sorted list2 = {sorting(list2)}")

