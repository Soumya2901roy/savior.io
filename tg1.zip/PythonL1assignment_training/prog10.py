def stepCount(n):
    r = 0
    i = 0
    steps = 0
    while r != n:
        steps += 1
        if r < n:
            i += 1
            r += abs(i)
        elif r > n:
            i -= 1
            r -= abs(i)
    return steps

num = int(input("Enter the number whose steps you want to count: "))
print(f"{stepCount(num)} Steps are needed to reach the number {num}")

