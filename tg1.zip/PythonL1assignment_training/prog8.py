str1 = """Python is a widely used high-level programming language for general-purpose programming, created by Guido van Rossum and first released in 1991. An interpreted language, Python has a design philosophy which emphasizes code readability (notably using whitespace indentation to delimit code blocks rather than curly braces or keywords), and a syntax which allows programmers to express concepts in fewer lines of code than possible in languages such as C++ or Java. The language provides constructs intended to enable writing clear programs on both a small and large scale .Python features a dynamic type system and automatic memory management and supports multiple programming paradigms, including object-oriented, imperative, functional programming, and procedural styles. It has a large and comprehensive standard library. Python interpreters are available for many operating systems, allowing Python code to run on a wide variety of systems. CPython, the reference implementation of Python, is open source software and has a community-based development model, as do nearly all of its variant implementations. CPython is managed by the non-profit Python Software Foundation."""

def buildDict(theStr):
    theDict = {}
    theList = []
    punct = '., \n()'
    for word in theStr.split(' '):
        word = word.lstrip(punct).rstrip(punct)
        theList.append(word)

    for i in range(0,len(theList)):
        if theList[i] in theDict:
            tmpList = theDict[theList[i]]
            if i < (len(theList)-1):
                if theList[i+1] not in tmpList:
                    tmpList.append(theList[i+1])
            theDict[theList[i]] = tmpList
        else:
            if i < (len(theList)-1):
                theDict.update({theList[i]:[theList[i+1]]})
    return theDict


results = buildDict(str1)
string = input("Enter the word which you want to check: ")
print(f"The words which follows '{string}' are {results[string]}")



