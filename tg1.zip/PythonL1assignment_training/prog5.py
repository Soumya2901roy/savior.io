# Given a list of numbers, return a list where all adjacent == elements have been reduced to a single element, 
# so [1, 2, 2, 3] returns [1, 2, 3]. You may create a new list or modify the passed in list. 
# [1, 2, 2, 3],  
# [2, 2, 3, 3, 3] 

def rmv_adj_dupe(lists):
    nl=[]
    for i in lists:
        if i not in nl:
            nl.append(i)
    return nl   


list1 = [1, 2, 2, 3]  
list2 = [2, 2, 3, 3, 3] 
print("Removing the adjacent duplicated we get: ")
print(f"List1: {rmv_adj_dupe(list1)}")
print(f"List2: {rmv_adj_dupe(list2)}")
