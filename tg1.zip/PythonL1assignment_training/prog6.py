# Write a function to print the information in the dictionary(bookstore) in the given format 

# bookstore={"New Arrivals":{"COOKING":["Everyday Italian","Giada De Laurentiis","2005","30.00"],"CHILDREN":["Harry Potter”, J K. Rowling","2005","29.99"],"WEB":["Learning XML","Erik T. Ray","2003","39.95"]}} 

# BOOKSTORE 
# 'Learning XML', 'Erik T. Ray', '2003', '39.95'  
# 'Everyday Italian', 'Giada De Laurent is', '2005', '30.00'] 
#  'Harry Potter', 'J K. Rowling', '2005', '29.99'] 

bookstore={"New Arrivals":{
                "COOKING":['Everyday Italian','Giada De Laurentiis','2005','30.00'],
                "CHILDREN":['Harry Potter', 'J K. Rowling','2005','29.99'],
                "WEB":['Learning XML','Erik T. Ray','2003','39.95']}
           }

print("BOOKSTORE")
for g, b in bookstore["New Arrivals"].items():
        print(f"'{b[0]}', '{b[1]}', '{b[2]}', '${b[3]}'")


