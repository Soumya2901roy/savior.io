# Given a list of strings, return the count of the number of strings where the string length is 2 or more and 
# the first and last chars of the string are the same.   
# ['axa', 'xyz', 'gg', 'x', 'yyy'] 
# ['x', 'cd', 'cnc', 'kk'] 
# ['bab', 'ce', 'cba', 'syanora'] 

list1 = [['axa', 'xyz', 'gg', 'x', 'yyy'],['x', 'cd', 'cnc', 'kk'],['bab', 'ce', 'cba', 'syanora']]
for item in list1:
    for s in item:
        if len(s)>2 and s[0]==s[-1]:
            print(s)
            



