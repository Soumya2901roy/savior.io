import re

str1="""
InterfaceIP-AddressOK? Method StatusProtocol 

  

FastEthernet0/0192.168.1.242YES manual upup  

FastEthernet1/0        unassignedYES unsetdown  

Serial2/0              192.168.1.250YES manual upup  

Serial3/0              192.168.1.233YES manual upup  

FastEthernet4/0        unassignedYES unset  down 

FastEthernet5/0        unassignedYES        unset down """

pattern = re.compile('^[F|S].*', re.MULTILINE)
resultList = pattern.findall(str1)
interface = re.compile('^[F|S].+\d/\d')
method    = re.compile('(manual|unset)')
status    = re.compile('(up|down)')

for item in resultList:
    print(f"{interface.search(item).group():20} {method.search(item).group():8} \t{status.search(item).group()}")


