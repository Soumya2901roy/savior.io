# Write program to find the biggest and Smallest of N numbers. PS: Use the functions to find biggest and smallest numbers. 
num=[]
for i in range(0,6):
    num.append(int(input("Enter a number: ")))

print(f"The biggest number in the list is {max(num)}")
print(f"The smallest number in the list is {min(num)}")