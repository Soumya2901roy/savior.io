#9.Write program to Add , subtract, multiply, divide 2 complex numbers.
import math
num1 = 2 + 3j
num2 = 4 + 5j

print(f"Sum of {num1} and {num2} is {num1+num2}")
print(f"Diff of {num1} and {num2} is {num1-num2}")
print(f"Product of {num1} and {num2} is {num1*num2}")
print(f"Dividing  {num1} by {num2} we get {num1/num2}")
