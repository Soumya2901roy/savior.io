#3.Write a program to find given number is odd or Even

num1 = int(input("Enter the number: "))

if num1 % 2 == 0 :
    print(f"{num1} is even")
else :
    print(f"{num1} is odd")