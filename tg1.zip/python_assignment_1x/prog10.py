#10.Using assignment operators, 
# perform following operations Addition, Substation, Multiplication, Division, Modulus, Exponent and Floor division operations
num1 = 80
num2 = 40

num1 += num2 
print(f"Addition with assignment operator {num1}")

num1 -= num2
print(f"Subtraction with assignment operator {num1}")

num1 *= num2
print(f"Multiplication with assignment operator {num1}")

num1 *= num2
print(f"Division with assignment operator {num1}")


num1 = 80
num2 = 4
print(f"Re-Initialised the values of num1 = {num1} and num2 = {num2}")

num1 **= num2
print(f"Expopent with assignment operator {num1}")

num1 //= num2
print(f"Floor division with assignment operator {num1}")

num1 %= num2
print(f"Modulus with assignment operator {num1}")