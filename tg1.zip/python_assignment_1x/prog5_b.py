# b) Find the biggest of three numbers, where three numbers are passed as command line arguments.
import sys
num1, num2, num3 = sys.argv[1], sys.argv[2], sys.argv[3]

if num1>num2 and num1>num3:
    print (f"The largest number is {num1}")
elif num2>num1 and num2>num3:
    print (f"The largest number is {num2}")
else:
    print (f"The largest number is {num3}")