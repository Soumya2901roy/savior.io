# Using loop structures print numbers from 1 to 100. and using the same loop print numbers from 100 to 1 (reverse printing) 
# a) By using For loop 
# b) By using while loop 
# c) Let mystring ="Hello world" print each character of mystring in to separate line using appropriate loop structure
print ("Forward\tBackward")
for i in range(1,101):
    print( f"{i: 6} {(101-i):6}")

print ("Forward\tBackward")

i=1
while i<=100:
    print( f"{i: 6} {(101-i):6}")
    i+=1 

mystring ="Hello world"
for c in mystring:
    print(c)