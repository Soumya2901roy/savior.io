# 14.Write a program to create two list A and B such that 
# List A contains Employee Id, List B contains Employee name ( minimum 10 entries in each list ) and perform following operations 
# a) Print all names on to screen 
# b) Read the index from the user and print the corresponding name from both list. 
# c) Print  The names from 4th position to 9th position
# d) Print all names from 3rd position till end of the list 
# e) Repeat list elements by specified number of times ( N- times, where N is entered by user) 
# f) Concatenate two lists and print the output. 
# g) Print element of list A and B side by side.( i.e. List-A First element , List-B First element )

employeeId=[1101,1102,1103,1104,1105,1106,1107,1108,1109,1109,1110]
employeeName=['ab', 'cd', 'ef', 'gh', 'ij','kl','mn','op','qr','st']
print(employeeName)
i = int(input("Enter the index : "))
print(f"The Employee id at index {i} is : {employeeId[i]}")
print(f"The Employee name at index {i} is : {employeeName[i]}")
print ("The names from 4th position to 9th position: ",employeeName[3:-1])
print ("All names from 3rd position till end of the list: ",employeeId[2:])

n=int(input("enter the no of times to repeat the list: "))

print (employeeId*n)
print (employeeName*n)
print ("Concatenate two lists and print the output. : \n",employeeName+employeeId)
for i in range(len(employeeName)):
    print(f"{employeeId[i]:5}  --  {employeeName[i]:5}")
 