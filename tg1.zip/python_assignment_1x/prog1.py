#1.Write a program to add , Subtract, Multiply, and divide 2 numbers

num1 = 80
num2 = 40

print(f"Sum of {num1} and {num2} is {num1+num2}")
print(f"Diff of {num1} and {num2} is {num1-num2}")
print(f"Product of {num1} and {num2} is {num1*num2}")
print(f"Dividing  {num1} by {num2} we get {num1/num2}")
