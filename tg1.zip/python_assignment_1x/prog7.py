#7.Create a tuple with at least 10 elements in it 
  #print all elements 
  #perform slicing 
  #perform repetition with * operator 
  #Perform concatenation wiht other tuple.
  
list1=input("Enter 10 elements of the list seperated by spaces: ").split(' ')
print("List1 = ", list1)

print("Slicing: \n",list1[2:5])
print("Repetion with * operatore: \n",list1 * 5)

list2=input("Enter 5 elements of another list seperated by spaces: ").split(' ')
print("list2= ",list2)
print (f"Concatenating list1 and list2 we get {list1 + list2}")