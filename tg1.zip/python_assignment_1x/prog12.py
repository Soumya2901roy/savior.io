#12.Read 10 numbers from user and find the average of all.
# a) Use comparison operator to check how many numbers are less than average and print them 
# b) Check how many numbers are more than average.
# c) How many are equal to average.
num=[]
for i in range(0,10):
    n = int(input(f"Enter num{i+1}:-  "))
    num.append(n)
sum = 0
for item in num:
    sum += item

avg = sum/10
print("Average is = ", avg)

avrg = int(avg)
high = 0
low = 0
same = 0
num.sort()
for item in num:
    if item == avg or item == avrg:
        same += 1
    elif item > avg or item > avrg:
        high += 1
    else:
        low += 1

print(f"{low} numbers are less than the average value.")
print(f"{high} numbers are more than the average value.")
print(f"{same} numbers are same as the average value.")




