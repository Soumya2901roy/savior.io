# 15.Create a list of 5 names and check given name exist in the List.
# a) Use membership operator ( IN ) to check the presence of an element. 
# b) Perform above task without using membership operator. 
# c) Print the elements of the list in reverse direction.

names =  ['Tom', 'Rick', 'Harry', 'James', 'Lily']

ch = input("Enter the name you want to check if exists: ")

if ch in names:
    print(f"{ch} exists in list")

for i in names:
    if i == ch:
        print(f"{ch} exists in list")
        break

print("List in reverse - ",names[::-1])