# Write program to perform following: 
# i) Check whether given number is prime or not. 
# ii) Generate all the prime numbers between 1 to N where N is given number. 


num=int(input("Enter the number you want to check prime or not: "))
if num < 2:
    print("Numbers less than 2 cannot be determined as Prime or composite.")
else:
    for i in range(2,num):
        if num%i == 0 and num!=2:
            print (f"{num} is not a prime number")
            break
    else:
        print (f"{num} is a prime number")

num2 = int(input("Enter the number till which you want to generate prime numbers: "))

for num in range(2,num2+1):
  if num>1:
    for i in range(2,num):
      if(num%i)==0:
        break
    else:
      print(num)
