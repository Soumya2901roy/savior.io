#6. Write a program to read string and print each character separately. 
#a) Slice the string using slice operator [:] slice the portion the strings to create a sub strings. 
#b) Repeat the string 100 times using repeat operator * 
#c) Read strig 2 and concatenate with other string using + operator.

#6
string1 = input("Enter a string: ")
for char in string1:
    print(char)

#6a
sub_str=string1[1:5]
print(f"{sub_str} is a sub string of {string1}")

#6b
print (f"Printing the string 100 times: \n {string1 * 100}")

#6c
string2 = input("Enter another string: ")
print(f"Concatenating both strings we get {string1 + string2}")
