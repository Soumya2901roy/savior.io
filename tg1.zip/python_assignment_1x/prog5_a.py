# 5.Write a program to receive 5 command line arguments and print each argument separately. 
# Example : >> python test.py arg1 arg2 arg3 arg4 arg5 
# a) From the above statement your program should receive arguments and print them each of them. 


import sys
arg1,arg2,arg3,arg4,arg5 = sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],
print (f"arg1 = {arg1}")
print (f"arg2 = {arg2}")
print (f"arg3 = {arg3}")
print (f"arg4 = {arg4}")
print (f"arg5 = {arg5}")

