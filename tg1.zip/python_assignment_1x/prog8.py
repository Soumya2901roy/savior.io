#8 Repeat program 7 with Tuples
# .Create a tuple with at least 10 elements in it 
  #print all elements 
  #perform slicing 
  #perform repetition with * operator 
  #Perform concatenation wiht other tuple.



tuple1=tuple(input("Enter 10 elements of the tuple seperated by spaces: ").split(' '))
print("tuple1 = ", tuple1)

print("Slicing: \n",tuple1[2:5])
print("Repetion with * operatore: \n",tuple1 * 5)

tuple2=tuple(input("Enter 5 elements of another tuple seperated by spaces: ").split(' '))
print("tuple2= ",tuple2)
print (f"Concatenating tuple1 and tuple2 we get {tuple1 + tuple2}")