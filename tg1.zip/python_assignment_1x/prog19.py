# 19.Using loop structures print even numbers between 1 to 100. 
# a) By using For loop , use continue/ break/ pass statement to skip odd numbers.
# i) break the loop if the value is 50 
# ii) Use continue for the values 10,20,30,40,50

# b) By using while loop, use continue/ break/ pass statement to skip odd numbers.
# i) break the loop if the value is 90 
# ii) Use continue for the values 60,70,80,90
import time
print("Using loop structures print even numbers between 1 to 100.") 
for i in range(1,101):
    if i%2==0:
        print (i)

#.a) By using For loop , use continue/ break/ pass statement to skip odd numbers.
print("By using For loop , use continue/ break/ pass statement to skip odd numbers") 
for i in range (1,101):
    if i%2!=0:
        continue
    print(i)

#.i)  break the loop if the value is 50
print("break the loop if the value is 50")
for i in range(1,101):
    if i%2!=0:
        continue
    print(i)
    if i==50:
        break
    
#.ii) Use continue for the values 10,20,30,40,50
print ("using continue for the values 10,20,30,40,50")    
for i in range (1,101):
    if i%2!=0:
        continue
    if i==10 or i==20 or i==30 or i==40 or i==50:
        continue
    print(i)

time.sleep(5)
#Using while loop structure to print even numbers between 1 to 100
print ("Using while loop structure to print even numbers between 1 to 100") 
i=1
while i<=100:
    if i%2==0:
        print(i)
    i+=1

time.sleep(5)

#.a) By using while loop , use continue/ break/ pass statement to skip odd numbers.
print ("By using while loop , use continue/ break/ pass statement to skip odd numbers.") 
i=0
while i<=100:
    if i%2!=0:
        pass
    else:
        print(i)
    i+=1

time.sleep(5)
#.i) break the loop if the value is 50 
print ("Breaking the for loop i ==50")
i=1
while i<=100:
    if i%2==0:
        print(i)
    if i==50:
        break
    i+=1  
time.sleep(5)

#.ii) Use continue for the values 10,20,30,40,50
print ("using continue for the values 10,20,30,40,50"    )
i=0
while i<=100:
    i+=1
    if i==10 or i==20 or i==30 or i==40 or i==50:
        continue
    if i%2==0:
        print(i)
    
    