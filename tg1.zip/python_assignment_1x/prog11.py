#11.Read 2 numbers to variable a and b and perform all bitwise operations on that numbers.

a = 10            
b = 20     
print(f"Value of a is {a}")       
print(f"Value of a is {b}")  
    
print(f"Doing BITWISE AND operation on {a} and {b} we get {a&b}")
print(f"Doing BITWISE OR operation on {a} and {b} we get {a|b}")
print(f"Doing BITWISE XOR operation on {a} and {b} we get {a^b}")
print(f"Doing BITWISE NOT operation on {a}  we get {~a}")
print(f"Doing BITWISE LEFT SHIFT operation on {a} we get {a<<2}")
print(f"Doing BITWISE RIGHT SHIFT operation on {a} we get {a>>2}")