#4.Write a program to find the number is Prime or not.

num=int(input("Enter the number you want to check prime or not: "))
if num < 2:
    print("Numbers less than 2 cannot be determined as Prime or composite.")
else:
    for i in range(2,num):
        if num%i == 0 and num!=2:
            print (f"{num} is not a prime number")
            break
    else:
        print (f"{num} is a prime number")