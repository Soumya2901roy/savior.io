#2.Write a program to find the biggest of 3 numbers ( Use If Condition )

num1 = int(input("Enter 1st number: "))
num2 = int(input("Enter 2nd number: "))
num3 = int(input("Enter 3rd number: "))

if num1>num2 and num1>num3:
    print (f"The largest number is {num1}")
elif num2>num1 and num2>num3:
    print (f"The largest number is {num2}")
else:
    print (f"The largest number is {num3}")