# Write a program to find the biggest of 4 numbers. a) Read 4 numbers from user using Input statement. 
# b) extend the above program to find the biggest of 5 numbers. (PS: Use IF and IF & Else, If and ELIf, and Nested IF)
num1 = int(input("Enter 1st number: "))
num2 = int(input("Enter 2nd number: "))
num3 = int(input("Enter 3rd number: "))
num4 = int(input("Enter 4th number: "))
l=0
if num1>num2 and num1>num3 and num1>num4:
    l = num1
    print (f"The largest number is {num1}")
elif num2>num1 and num2>num3 and num2>num4:
    l = num2
    print (f"The largest number is {num2}")
elif num3>num1 and num3>num2 and num3>num4:
    l = num3
    print (f"The largest number is {num3}")
else:
    l = num4
    print(f"The largest number is {num4}")

num5 = int(input("Enter 5th number: "))
if num5>l:
    print(f"The largest number is {num5}")
else:
    print(f"The largest number is {l}")