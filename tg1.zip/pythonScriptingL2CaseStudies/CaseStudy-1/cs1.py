#!/usr/bin/python3




import queue
import threading
import sys

def checkFile(filename):
    lc=0
    wc=0
    cc=0
    #print("here")
    with open(filename, 'r') as file:
        lines=file.readlines()      
        lc = len(lines)                 #line count
        #print(lc)
        for item in lines:
            words = item.split()
            wc += len(words)            #word count
            for word in words:
                for c in word:
                    cc+=1               #character count
    que.put([filename,lc,wc,cc])

que = queue.Queue()
for f in sys.argv[1:]:
    t = threading.Thread(target=checkFile, args=[f,])
    t.start()
    t.join()
    
qList = list(que.queue)
#print(queueList)
qList.sort()
x=""
print(f"FILE NAME{x:<5}Line Count{x:<5}WORD COUNT{x:<5}Charcter COUNT{x:<5}")
for eachitem in qList:
    print(f"{eachitem[0]:<15}{eachitem[1]:<15}{eachitem[2]:<15}{eachitem[3]:<15}")
