source = """
class test:
    class inner_class:
        pass
    pass

class test2:
    pass
"""

import ast
p = ast.parse(source)
classes = [node.name for node in ast.walk(p) if isinstance(node, ast.ClassDef)]
print(classes)