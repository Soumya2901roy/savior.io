# Create a class called Circle and write the methods to calculate the area and circumference of a circle given the radius.
class Circle(object):
    
    def calc_area(self, radius):
        try:
            print(f"The area of Circle with radius {radius} is {22/7 * (radius**2)}")
        except Exception as e:
            print("Area could not be calculated as we caught exception => ", e)
        
    
    def calc_circumference(self, radius):
        try:
            print(f"The Circumference of Circle with radius {radius} is {2  * 22/7 * radius}")
        except Exception as e:
            print("Area could not be calculated as we caught exception => ", e)
        

obj = Circle()
radius = int(input("Enter the radius of the circle: "))
obj.calc_area(radius)
obj.calc_circumference(radius)

