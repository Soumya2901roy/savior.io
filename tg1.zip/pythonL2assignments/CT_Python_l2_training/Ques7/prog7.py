#Write a code to compare two string data based on the length of the string hint; __gt__ method

class CompareStrings():

    def __init__(self, string):
        self.string=string        
        
    def __gt__(self, other):
        if len(self.string) > len(other.string):
            print(f"Length of '{self.string}' is greater than '{other.string}'")
        elif len(self.string) < len(other.string):
            print(f"Length of '{self.string}' is less than '{other.string}'")
        else:
            print(f"Length of '{self.string}' is same as '{other.string}'")
 
string1 = input("Enter the String 1 : ")
string2 = input("Enter the String 2 : ")
st1 = CompareStrings(string1)
st2 = CompareStrings(string2)

if (st1>st2):
    print("Resolved")


