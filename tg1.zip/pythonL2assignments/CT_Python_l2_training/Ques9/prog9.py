# Write a class called Circle and write the methods to calculate the area and circumference of the circle by initialing the radius of the circle. Hint __init__ method
class Circle(object):

    def __init__(self,radius):
        self.radius = radius
    
    def calc_area(self):
        try:
            print(f"The area of Circle with radius {self.radius} is {22/7 * (self.radius**2)}")
        except Exception as e:
            print("Area could not be calculated as we caught exception => ", e)
        
    
    def calc_circumference(self):
        try:
            print(f"The Circumference of Circle with radius {self.radius} is {2  * 22/7 * self.radius}")
        except Exception as e:
            print("Area could not be calculated as we caught exception => ", e)
        

radius = int(input("Enter the radius of the circle: "))
obj = Circle(radius)

obj.calc_area()
obj.calc_circumference()