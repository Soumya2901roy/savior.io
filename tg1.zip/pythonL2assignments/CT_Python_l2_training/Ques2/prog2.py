# 2.  Given email='From abc.xyz@pqr.com Mon Dec 29 01:12:15 2016'
# write a regular  expression to extract 
# a. email id
# b. domain name
# c. time

import re

email_line = 'From abc.xyz@pqr.com Mon Dec 29 01:12:15 2016'

p_email = '([a-zA-Z0-9+._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)'
x = re.findall(p_email,email_line)
print(f"The Email ID from the given text is {x[0]}")

p_domain = '(?<=@)[^.]+(?=\.)'
d = re.findall(p_domain,email_line)
print (f"The domain name from the given line is {d[0]}")

p_time = '([0-2][0-3]:[0-5][0-9]:[0-5][0-9])'
t = re.findall(p_time,email_line)
print (f"The time mentioned in the given line is {t[0]}")





