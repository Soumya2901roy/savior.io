# Write a code to overload __add__ method to perform  2 x 2 matrix addition
class Matrix(object):
    
    def __init__(self, matrix):
        
        self.matrix = matrix
        if len(matrix) != 2:
            raise Exception("Only 2x2 Matrices Accepted")

    def __add__(self,other):
        sum_matrix = [[0,0],[0,0]]
        for i in range(0,2):
            for j in range(0,2):
                sum_matrix[i][j] = self.matrix[i][j] + other.matrix[i][j]
        return sum_matrix
 
print("This code will only support MATRIX addition for 2x2 matrices: ")
matrix1=[]
matrix2=[]
for m in range(0,2): #start taking inpput for Matrix elements
    print(f"Matrix {m+1}: ")
    for row in range(0,2):
        temp=[]
        for column in range(0,2):
            element = int(input(f"For Matrix {(m+1)} Enter the Element at row-{row} and column-{column}: "))
            temp.append(element)
        if m == 0:
            matrix1.append(temp)
        else:
            matrix2.append(temp)
    print("------------------")

# Displaying the matrices
for i in matrix1:
    print(f"|{i[0]:<4}{i[1]:4}|") 
print("+")
for i in matrix2:
    print(f"|{i[0]:<4}{i[1]:4}|") 
print("------------------")

m1 = Matrix(matrix1)
m2 = Matrix(matrix2) 

sum = m1 + m2
for i in sum:
    print(f"|{i[0]:<4}{i[1]:4}|")


