import mathnew

num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
mathnew.add(num1,num2)
mathnew.sub(num1,num2)
mathnew.mul(num1,num2)
mathnew.div(num1,num2)
mathnew.sqrt(num1)
