def add(num1,num2):
        try:
            print(f"Sum of {num1} and {num2} is {num1+num2}")
        except Exception as e:
            print("Addition is not performed as we have encountered an exception -> ", e)
        
def sub(num1,num2):
    try:
        print(f"Diff of {num1} and {num2} is {num1-num2}")
    except Exception as e:
        print("Subtraction is not performed as we have encountered an exception -> ", e)
        
def div(num1,num2):
    try:
        print(f"Dividing {num1} by {num2} we get {num1/num2}")
    except Exception as e:
        print("Division is not performed as we have encountered an exception -> ", e)

def mul(num1,num2):
    try:
        print(f"Product of {num1} and {num2} is {num1*num2}")
    except Exception as e:
        print("Multiplication is not performed as we have encountered an exception -> ", e)

def sqrt(num1):
    try:
        print(f"Square root of {num1} is {num1**0.5}")
    except Exception as e:
        print("Square root is not performed as we have encountered an exception -> ", e)
