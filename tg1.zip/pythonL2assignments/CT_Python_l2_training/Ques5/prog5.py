#      5.   Write a code to implement a child class called mathnew and parent classes as sqroot,   addition,subtraction, multiplication and division. Use the super() function to inherit the parent methods.
class Calculator():

    def add(self,num1,num2):
        try:
            print(f"Sum of {num1} and {num2} is {num1+num2}")
        except Exception as e:
            print("Addition is not performed as we have encountered an exception -> ", e)
        
    def sub(self,num1,num2):
        try:
            print(f"Diff of {num1} and {num2} is {num1-num2}")
        except Exception as e:
            print("Subtraction is not performed as we have encountered an exception -> ", e)
          
    def div(self,num1,num2):
        try:
            print(f"Dividing {num1} by {num2} we get {num1/num2}")
        except Exception as e:
            print("Division is not performed as we have encountered an exception -> ", e)

    def mul(self,num1,num2):
        try:
            print(f"Product of {num1} and {num2} is {num1*num2}")
        except Exception as e:
            print("Multiplication is not performed as we have encountered an exception -> ", e)

    def sqrt(self,num1):
        try:
            print(f"Square root of {num1} is {num1**0.5}")
        except Exception as e:
            print("Square root is not performed as we have encountered an exception -> ", e)
	  
class Mathnew(Calculator):

    def __init__(self,num1,num2):
       self.num1 = num1
       self.num2 = num2
       super(Mathnew, self).add(num1,num2)
       super(Mathnew, self).sub(num1,num2)
       super(Mathnew, self).mul(num1,num2)
       super(Mathnew, self).div(num1,num2)
       super(Mathnew, self).sqrt(num1)

num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
obj = Mathnew(num1, num2)