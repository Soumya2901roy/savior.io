# 4.  Write a code to implement the following methods by defining a class called Mymath
# a) with__init__  
# 1. sqroot
# 2. addition
# 3. subtraction
# 4. multiplication
# 5. division

class Mymath:

    def __init__(self, num1, num2):
        self.num1 = num1
        self.num2 = num2
        

    def add(self):
        try:
            print(f"Sum of {self.num1} and {self.num2} is {self.num1+self.num2}")
        except Exception as e:
            print("Addition is not performed as we have encountered an exception -> ", e)
        
    def sub(self):
        try:
            print(f"Diff of {self.num1} and {self.num2} is {self.num1-self.num2}")
        except Exception as e:
            print("Subtraction is not performed as we have encountered an exception -> ", e)
          
    def div(self):
        try:
            print(f"Dividing {self.num1} by {self.num2} we get {self.num1/self.num2}")
        except Exception as e:
            print("Division is not performed as we have encountered an exception -> ", e)

    def mul(self):
        try:
            print(f"Product of {self.num1} and {self.num2} is {self.num1*self.num2}")
        except Exception as e:
            print("Multiplication is not performed as we have encountered an exception -> ", e)

    def sqrt(self):
        try:
            print(f"Square root of {self.num1} is {self.num1**0.5}")
        except Exception as e:
            print("Square root is not performed as we have encountered an exception -> ", e)

num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
m = Mymath(num1, num2)
m.add()
m.sub()
m.div()
m.mul()
m.sqrt()