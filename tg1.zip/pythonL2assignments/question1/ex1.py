# Import module support
import mathnew

# Now you can call defined function that module as follows
mathnew.sqroot(64)
mathnew.addition(12,2)
mathnew.subtraction(11,11)
mathnew.multiplication(14,[])
mathnew.division(1,2)

