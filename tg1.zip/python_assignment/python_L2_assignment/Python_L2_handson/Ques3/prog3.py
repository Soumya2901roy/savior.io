c = 0

def f2(x):
    c+= 1
    b = x + c
    print(c)
    return b

try:
    print(f2(1))
except Exception as exp:
    print("ERROR in the code , Please check because ",exp)
finally:
    print(c)