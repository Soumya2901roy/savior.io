# Implement a simple generator for Fibonacci series
def fibonacci():    
    a = 0
    b = 1
    while True:  
        yield a
        a, b = a + b , a 

try:
    num = int (input ("Enter the number of terms of fibonacci series you want to print: "))
    fib = fibonacci()
    for i in range(0,num):
        print ( next ( fib ))
except Exception as e:
    print("Input has faced an exception as ",e)
