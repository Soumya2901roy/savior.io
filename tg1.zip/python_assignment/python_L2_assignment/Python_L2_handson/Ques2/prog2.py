import time
def main():
        
    
    i=1
    string="This is a string"
    try:
        print("This line is the first line.")
        print(i+j) #uncomment this line for NameError
        #print(i/0) #uncomment this line for ArithmeticError

        #uncomment the below block for KeyboardInterrupt
        # for index in range(1,5):
        #     time.sleep(1)
        #     print(index)


            
    except KeyboardInterrupt:
        print("KeyboardInterrupt")
    except NameError:
        print("NameError")
    except ArithmeticError:
        print("Arithmetic Error")
    
    else:
        print("No errors encountered so in the ELSE block.")
    
    finally:
        print("Finally Wipro is always there with me.")

        

main()