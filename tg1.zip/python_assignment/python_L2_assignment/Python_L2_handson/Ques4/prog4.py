import re
def regexA(inp_string):
    pattern='(^\d*.*\d$)'   # a. digit at the beginning of the string and a digit at the end of the string
    if re.findall(pattern,inp_string):
        print(f"{inp_string} has been succesfully matched with your regex for 'Digit at the beginning of the string and a digit at the end of the string.' ")
    else:
        print("NO MATCH found for REGEX A")
        str_temp=input("Enter a string again to check with the Regex A: ")
        regexA(str_temp)

def regexB(inp_string):
    pattern='(^(\s*|\w*)$)'   # A string that contains only whitespace characters or word characters
    if re.findall(pattern,inp_string):
        print(f"{inp_string} has been succesfully matched with your regex for 'A string that contains only whitespace characters or word characters.' ")
    else:
        print("NO MATCH found for REGEX B")
        str_temp=input("Enter a string again to check with the Regex B: ")
        regexB(str_temp)

def regexC(inp_string):
    pattern='(^\S*$)'   # c. A string containing no whitespace characters 
    if re.findall(pattern,inp_string):
        print(f"{inp_string} has been succesfully matched with your regex for 'A string containing no whitespace characters ' ")
    else:
        print("NO MATCH found for REGEX C")
        str_temp=input("Enter a string again to check with the Regex C: ")
        regexC(str_temp)
        

str1=input("Enter a string to check with the Regex A: ")
regexA(str1)
str2=input("Enter a string to check with the Regex B: ")
regexB(str2)
str3=input("Enter a string to check with the Regex C: ")
regexC(str3)