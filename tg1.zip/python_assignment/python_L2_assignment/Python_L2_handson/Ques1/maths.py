from calc import calc_factorial,calc_trigonometry

#1 To find the factorial
num = int(input("Enter the number whose factorial you want: "))
calc_factorial(num)

#2 To get the trigonometric values
deg = int(input("Enter the value in degrees for the triginometric functions: "))
calc_trigonometry(deg)