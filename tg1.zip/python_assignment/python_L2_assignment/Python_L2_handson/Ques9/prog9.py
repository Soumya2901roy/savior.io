class Iterator:
    def __init__(self, low, high):
        # self.current = low - 1
        # self.high = high
        self.current = high + 1
        self.low = low

    def __iter__(self):
        
        return self

    def __next__(self): 
        self.current -= 1
        if self.current >= self.low:
            return self.current
        raise StopIteration

l = int(input("Enter the lower limit: "))
h = int(input("Enter the higher limit: "))

print("Iterating Backwards in the range given with step size = 1 ")
for i in Iterator(l,h):
    print(i)