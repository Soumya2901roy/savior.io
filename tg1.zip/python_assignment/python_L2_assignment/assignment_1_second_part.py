"""
1.	Write a code to implement the package  below and distribute it.
Mathnew package with following modules
1. sqroot
2. addition
3. subtraction
4. multiplication
5. division
"""


import Mathnew 
Mathnew.division(1,4)
Mathnew.multiplication(1,6)
Mathnew.subtraction(3,7)
