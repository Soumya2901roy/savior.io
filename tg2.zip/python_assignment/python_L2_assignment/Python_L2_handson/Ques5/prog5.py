import re
line_list=[]
with open('file5.txt','r+') as f:
    line_list=f.read().split("\n")

pattern='([aeiou][aeiou])'
for word in line_list:
    if re.findall(pattern,str(word)):
        print(str(word))
    