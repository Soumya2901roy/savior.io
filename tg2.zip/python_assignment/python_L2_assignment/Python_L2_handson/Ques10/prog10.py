import time 
import math 
   
def calculate_time(func): 
      
    def inner1(*args): 
        begin = time.time() 
        print(f"Start time : {time.ctime(begin)}")
        func(*args) 
        end = time.time() 
        print(f"End time : {time.ctime(end)}")
        print(f"Time elapsed for the function {func.__name__}  = {end - begin}" ) 
    return inner1 
 
@calculate_time
def myFunc(num): 
   
    for i in range (0,num):
        print(i)
        time.sleep(1)
 
myFunc(5) 