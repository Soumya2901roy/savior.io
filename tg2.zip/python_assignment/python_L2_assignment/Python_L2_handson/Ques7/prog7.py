class First: 
    def __init__(self):
        print("Default in class FIRST")

    def method1(self):
        print("Method1 in class FIRST")
     
class Second(First): 
    def __init__(self):
        print("Default in class SECOND")

    def method1(self):
        print("Method1 in class SECOND")  
        First.method1(self)
       
class Third(First): 
    def __init__(self):
        print("Default in class THIRD")

    def method1(self):
        print("Method1 in class THIRD") 
        First.method1(self)
        
class Fourth(Second,Third): 
    def __init__(self):
        print("Default in class FOURTH")

    def method1(self):
        print("Method1 in class THIRD")
        Second.method1(self)
        Third.method1(self)
     

f = Fourth()
f.method1()