import math
def calc_factorial(num1):
    print(f"The factorial of {num1} is {math.factorial(num1)}")

def calc_log10(num1):
    print(f"The value of log10({num1}) is {math.log10(num1)}")

def calc_radians(num1):
    print(f"Converting {num1} degrees to radians we get {math.radians(num1)}")

def calc_trigonometry(num1):
    #print(f"Converting {num1} degrees to radians we get {math.radians(num1)}")
    rad_value = math.radians(num1)
    print(f"sin ({num1} degrees) = {math.sin(rad_value)}")
    print(f"cos ({num1} degrees) = {math.cos(rad_value)}")
    print(f"tan ({num1} degrees) = {math.tan(rad_value)}")    

    