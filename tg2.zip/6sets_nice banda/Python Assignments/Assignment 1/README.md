Please refer to the Word document for screenshots as well.


PYTHON PROGRAMS

1)	#!/usr/bin/python
a, b = 20, 10
c = a + b
print “\n Addition of two numbers is”, c
c = a – b
print “\n Subtraction of two numbers is”, c
c = a * b 
print “\n Multiplication of two numbers is”, c
c = a / b 
print “\n Division of two numbers is”, c


 

2)	#!/usr/bin/python
a, b, c = 20, 10, 30
if  a > b and  a > c  :
print “Biggest of three numbers is”, a
if  b > a and  b> c :
print “Biggest of three numbers is”, b
if c > a and  c > b :
print “Biggest of three numbers is”, c
 


3)	#!/usr/bin/python
a = 10
b = a % 2
if  b == 0 :
print “ Given number is”, c, “even”
else :
print “Given number is”, c, “odd”

 

4)	#!usr/bin/python
a = 7
            	for i in ( 2, a-1 )
		if  a % i == 0 :
		print “ The given number “, a “ is not prime”
		else :
		print “ The given number “, a “is prime”

 

5)	#!/usr/bin/python
import sys
print “ First number is ”, arg1
print “ Second number is ”, arg2
	        print “ Third number is ”, arg3
	        print “The biggest of three numbers is ”, max ( arg1, arg2, arg3 )

 
6)	#!usr/bin/python
str1 = “Chennai”
str2 = “city”
for i in range str1
print “current letter is”, i
str3 = str1[2:5]
print “ sub-string is ”, str3
print “ Repeated string is “, str1 * 100
print “ Concatenated string is “, str1 + str2

 

7)	#!/usr/bin/python
List = [ 12, 23, ‘Hello’, 60.6, ‘Chennai’ ]
List1 = [ 21, 32, 60 ]
a = List [ 1:3 ] 
b = List * 2
c = List + List1
print List
print “\n”, a 
print “\n”, b 
print “\n”, c


 

8)	#!/usr/bin/python
Tuple = ( 12, 23, ‘Hello’, 60.6, ‘Chennai’ )
Tuple1 = ( 21, 32, 60 )
a = Tuple[ 1:3 ] 
b = List * 2
c = List + List1
print List
print “\n”, a 
print “\n”, b 
print “\n”, c


 

9)	#!/usr/bin/python
	        a = complex(arg[0], arg[1])
	        b = complex (arg[2], arg[3])
        c = a + b
print “\n Addition of two numbers is”, c
c = a – b
print “\n Subtraction of two numbers is”, c
c = a * b 
print “\n Multiplication of two numbers is”, c
c = a / b 
print “\n Division of two numbers is”, c


 

10)	#!/usr/bin/python
arg[0] += arg[1]
print “\n Addition of two numbers is”, c
arg[0] -= arg[1]
print “\n Subtraction of two numbers is”, c
arg[0] *= arg[1] 
print “\n Multiplication of two numbers is”, c
arg[0] /= arg[1] 
print “\n Division of two numbers is”, c
arg[0] %= arg[1]
print “\n modulus of two numbers is”, c
arg[0] **= arg[1]
print “\n Exponentiation of two numbers is”, c
arg[0] //= arg[1]
print “\n Floor division of two numbers is”, c

 ss


11)  #!/usr/bin/python
a = arg[0] and arg[1]
b = arg[0] or arg[1]
c = not(arg[0] and arg[1])
print a
print b
print c

 

          
	    
                  
	

           

  


			


