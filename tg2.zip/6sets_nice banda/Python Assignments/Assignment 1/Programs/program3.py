a = 10
b = a % 2
if  b == 0 :
    print " Given number is", a, "even"
else :
    print "Given number is", a, "odd"
