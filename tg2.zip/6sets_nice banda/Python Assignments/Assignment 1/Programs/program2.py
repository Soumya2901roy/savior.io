a, b, c = 20, 10, 30
if  a > b and  a > c  :
    print "Biggest of three numbers is", a
if  b > a and  b> c :
    print "Biggest of three numbers is", b
if c > a and  c > b :
    print "Biggest of three numbers is", c
