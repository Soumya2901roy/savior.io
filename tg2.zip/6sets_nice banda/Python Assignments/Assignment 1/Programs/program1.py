a, b = 20, 10
c = a + b
print "\n Addition of two numbers is", c
c = a - b
print "\n Subtraction of two numbers is", c
c = a * b
print "\n Multiplication of two numbers is", c
c = a / b
print "\n Division of two numbers is", c
