str1 = "Chennai"
str2 = "city"
for i in  str1:
    print "current letter is", i
str3 = str1[2:5]
print " sub-string is ", str3
print " Repeated string is ", str1 * 100
print " Concatenated string is ", str1 + str2
