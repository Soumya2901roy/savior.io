Tuple = ( 12, 23, "Hello", 60.6, "Chennai" )
Tuple1 = ( 21, 32, 60 )
a = Tuple[ 1:3 ]
b = Tuple * 2
c = Tuple + Tuple1
print Tuple
print "\n", a
print "\n", b
print "\n", c
