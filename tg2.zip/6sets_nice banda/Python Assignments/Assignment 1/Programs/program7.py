List = [ 12, 23, "Hello", 60.6, "Chennai" ]
List1 = [ 21, 32, 60 ]
a = List [ 1:3 ]
b = List * 2
c = List + List1
print List
print "\n", a
print "\n", b
print "\n", c
