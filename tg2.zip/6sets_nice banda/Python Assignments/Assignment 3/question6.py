'''
a) Slice the string using slice operator [:] slice the portion the strings to create a sub strings.
b) Repeat the string 100 times using repeat operator *
c) Read strig 2 and  concatenate with other string using + operator.
'''

str1 = "Hi,I'm Amit"
# Slicing the string
print str1[1:]
print str1[2:12:2]

#Repeating the string
str2 = 's'*100
print str2

#Concatenating another string
str3 = str1+str2
print str3
