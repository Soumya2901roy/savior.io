#Write program to Add , subtract, multiply, divide 2 complex numbers.


z1 = complex(3+4j)
z2 = complex(5-12j)

print z1+z2
print z1-z2
print z1*z2
print z1/z2
