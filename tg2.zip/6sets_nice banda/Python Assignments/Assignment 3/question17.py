'''
Write program to find  the biggest  and Smallest of N numbers.
      PS: Use the functions to find biggest and  smallest numbers.

'''
lst = [1,2,3,4,5,6,7,8,9]

print max(lst)
print min(lst)
