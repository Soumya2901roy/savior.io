'''
Using assignment operators, perform following operations
Addition, Subtraction, Multiplication, Division, Modulus, Exponent and Floor division operations

'''
x = 2
y = -12

#Addition
print x+y

#Subtraction
print x-y

#Multiplication
print x*y

#Division
print x/y

#Modulus
print abs(x)

#Exponent
print x**2

#Floor division
print x//y
