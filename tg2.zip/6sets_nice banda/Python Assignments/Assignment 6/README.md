Python L2 Assignments to upload:

1.	Write a code to implement the package  below and distribute it.
Mathnew package with following modules
1. sqroot
2. addition
3. subtraction
4. multiplication
5. division

2.	 Given email='From abc.xyz@pqr.com Mon Dec 29 01:12:15 2016'
write a regular  expression to extract 
a. email id
b. domain name
c. time

3.	  Write a code to implement the following methods by defining a class called Mymath
a) without __init__  
1. sqroot
2. addition
3. subtraction
4. multiplication
5. division

4.	 Write a code to implement the following methods by defining a class called Mymath
a) with__init__  
1. sqroot
2. addition
3. subtraction
4. multiplication
5. division


5.   Write a code to implement a child class called mathnew and parent classes as sqroot,   addition,subtraction, multiplication and division. Use the super() function to inherit the parent methods.

6.	Write a code to overload __add__ method to perform  2 x 2 matrix addition

7.	Write a code to compare two string data based on the length of the string hint; __gt__ method

8.	Create a class called Circle and write the methods to calculate the area and circumference of a circle given the radius.

9.	Write a class called Circle and write the methods to calculate the area and circumference of the circle by initialing the radius of the circle. Hint __init__ method

10.	Create a class called First and two classes called Second  and Third which inherit from First. Create class called Fourth which inherits from Second and Third. Create a common method called method1 in all the classes and provide the Method Resolution Order





